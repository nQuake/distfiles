Load an alternative skybox using the console:
syntax: /loadsky <skyname>
i.e.: /loadsky stormydays