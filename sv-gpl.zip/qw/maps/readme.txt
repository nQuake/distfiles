These are AquaShark's GPL maps with embedded color lightmaps
(BSPX format, should work in any ezQuake released in 2011 or later)
With ezQuake, should be playable on any server (it will take care of the CRCs).

Maps: dm2..dm6, e1m2

Not included are AquaShark's dm1 and end, they seem to be 
incompatible with the originals (inline brush numbers don't match? )

Enjoy.

-- Tonik, 15.08.2012
