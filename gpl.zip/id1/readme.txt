When you purchase the full version of Quake, copy pak1.pak to this directory and remove gpl_maps.pk3.

You can buy Quake here:
http://store.steampowered.com/app/2310/